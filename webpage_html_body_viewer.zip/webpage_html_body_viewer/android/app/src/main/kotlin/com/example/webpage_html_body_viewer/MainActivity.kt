package com.example.webpage_html_body_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
